#!/usr/bin/env python3
import os
import sys
import site




# === Путь к проекту ===
PROJECT_ROOT = '/var/www/u3160248/data/www/itrun.kg'

# === Путь к виртуальному окружению ===
VENV_PATH = os.path.join(PROJECT_ROOT, 'venv')

# Добавляем site-packages виртуального окружения
site_packages = os.path.join(VENV_PATH, 'lib', 'python3.10', 'site-packages')
site.addsitedir(site_packages)

# Добавляем проект в sys.path
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


# === Django настройки ===
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'it_run.settings')

# Passenger cache (иначе бывает PermissionError)
os.environ['PYTHON_EGG_CACHE'] = os.path.join(PROJECT_ROOT, '.python-eggs')

# === Запуск приложения ===
from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()



