from modeltranslation.translator import register, TranslationOptions
from .models import Course, TeamMember, FAQ

@register(Course)
class CourseTranslationOptions(TranslationOptions):
    fields = ('title', 'topics_text')


@register(TeamMember)
class TeacherTranslationOptions(TranslationOptions):
    fields = ('position',)


@register(FAQ)
class FAQTranslationOptions(TranslationOptions):
    fields = ('question', 'answer')
