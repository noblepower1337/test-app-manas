from django.views.generic import TemplateView
from landing.models import Course, TeamMember, FAQ, ContactInfo


class HomeView(TemplateView):
    template_name = "index.html"
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['courses'] = Course.objects.filter(is_visible=True)
        context['team_members'] = TeamMember.objects.all()
        context['faqs'] = FAQ.objects.all()
        context['contacts'] = ContactInfo.objects.first() or None
        return context
