from django.test import TestCase
from django.urls import reverse
from django.utils import translation

from landing.models import Course, TeamMember, FAQ, ContactInfo


class HomeViewTests(TestCase):

    def setUp(self):

        self.course = Course.objects.create(
            title="Back-End разработка",
            topics_text="Python на Django, Git, GitHUB, SQL, SQLite3, DjangoRESTFramework",
            is_visible=True
        )

        self.teacher = TeamMember.objects.create(
            name="Суксурали уулу Токтосун",
            position="Python Back-End разработчик"
        )

        self.faq = FAQ.objects.create(
            question="Вопрос?",
            answer="Ответ"
        )

        self.contact = ContactInfo.objects.create(
            address="г.Жалал-Абад ул.Жусуп Бакиева 7",
            working_hours="пн-сб с 9:00 до 20:00",
            phone_number="+996 955 606 050",
            whatsapp_number="+996 955 606 050",
            email="itrunacademy@mail.com",
        )

        self.url = reverse("home")
        self.response = self.client.get(self.url)

    def test_status_code_and_template(self):
        self.assertEqual(self.response.status_code, 200)
        self.assertTemplateUsed(self.response, "index.html")

    def test_context_contains_all_models(self):
        context = self.response.context
        self.assertIn("courses", context)
        self.assertIn("teachers", context)
        self.assertIn("faqs", context)
        self.assertIn("contacts", context)

        self.assertEqual(context["courses"].count(), 1)
        self.assertEqual(context["teachers"].count(), 1)
        self.assertEqual(context["faqs"].count(), 1)
        self.assertIsNotNone(context["contacts"])
        self.assertEqual(context["contacts"].email, "itrunacademy@mail.com")
        self.assertEqual(context["contacts"].phone_call, "+996 955 606 050")

    def test_only_visible_courses_are_displayed(self):
        Course.objects.create(
        title="Backend курс на Django",
        topics_text="Git & GitHub, HTML, CSS, JS, SQL, SQLite3, Django REST Framework",
        is_visible=False
        )
        response = self.client.get(self.url)
        self.assertContains(response, self.course.title)
        self.assertNotContains(response, "Backend курс на Django")

    def test_faqs_displayed_on_page(self):
        FAQ.objects.create(question="Fake question?", answer="Fake answer")
        response = self.client.get(self.url)
        self.assertContains(response, self.faq.question)
        self.assertContains(response, self.faq.answer)
        self.assertContains(response, "Fake question?")
        self.assertContains(response, "Fake answer")

