from django.contrib import admin
from modeltranslation.admin import TabbedTranslationAdmin
from solo.admin import SingletonModelAdmin
from .models import Course, TeamMember, ContactInfo,  FAQ


@admin.register(Course)
class CourseAdmin(TabbedTranslationAdmin):
    list_display = ("title", "is_visible")
    search_fields = ("title", "topics_text")
    list_filter = ("is_visible",)
    list_editable = ("is_visible",)


@admin.register(TeamMember)
class TeacherAdmin(TabbedTranslationAdmin):
    list_display = ("name", "position", "instagram")
    search_fields = ("name", "position")
    list_filter = ("position",)


@admin.register(ContactInfo)
class ContactInfoAdmin(SingletonModelAdmin):
    list_display = ("phone_number", "email", "address")


@admin.register(FAQ)
class FAQAdmin(TabbedTranslationAdmin):
    list_display = ("question", "answer")
    search_fields = ("question", "answer")
