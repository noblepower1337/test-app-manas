from django.db import models
from solo.models import SingletonModel


class Course(models.Model):
    """Курс: название, список тем и статус отображения на сайте"""
    title = models.CharField(max_length=100, verbose_name="Название курса")
    topics_text = models.TextField(
        verbose_name="Темы и инструменты",
        help_text="Каждая тема с новой строки"
    )
    is_visible = models.BooleanField(default=True, verbose_name="Отображать на сайте")

    def get_topics_list(self):
        """Возвращает темы курса в виде списка строк"""
        return self.topics_text.split('\n')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "Курс"
        verbose_name_plural = "Курсы"


class TeamMember(models.Model):
    """Член команды: ФИО, должность, фото и ссылки на соцсети"""
    name = models.CharField(max_length=100, verbose_name="ФИО")
    position = models.CharField(max_length=255, verbose_name="Должность")
    photo = models.ImageField(
        upload_to='team/',
        blank=True,
        null=True,
        verbose_name="Фотография"
    )
    instagram = models.URLField(blank=True, null=True, verbose_name="Instagram")
    telegram = models.URLField(blank=True, null=True, verbose_name="Telegram")
    facebook = models.URLField(blank=True, null=True, verbose_name="Facebook")
    linkedin = models.URLField(blank=True, null=True, verbose_name="LinkedIn")

    def __str__(self):
        return f"{self.name} — {self.position}"

    class Meta:
        verbose_name = "Член команды"
        verbose_name_plural = "Состав команды"


class ContactInfo(SingletonModel):
    """Контактная информация: адрес, график, телефоны, email и соцсети"""
    address = models.CharField(max_length=255, verbose_name="Адрес")
    working_hours = models.CharField(max_length=255, verbose_name="Режим работы")
    phone_number = models.CharField(max_length=50, verbose_name="Телефон")
    whatsapp_number = models.CharField(max_length=50, verbose_name="WhatsApp")
    email = models.EmailField(verbose_name="Email")
    instagram = models.URLField(blank=True, null=True, verbose_name="Instagram")
    telegram = models.URLField(blank=True, null=True, verbose_name="Telegram")
    facebook = models.URLField(blank=True, null=True, verbose_name="Facebook")
    linkedin = models.URLField(blank=True, null=True, verbose_name="LinkedIn")

    def __str__(self):
        return "Контакты сайта"

    class Meta:
        verbose_name = "Контакт"
        verbose_name_plural = "Контакты"


class FAQ(models.Model):
    """Вопрос-ответ для раздела часто задаваемых вопросов"""
    question = models.CharField(max_length=255, verbose_name="Вопрос")
    answer = models.TextField(verbose_name="Ответ")

    def __str__(self):
        return self.question

    class Meta:
        verbose_name = "Вопрос-ответ"
        verbose_name_plural = "Вопросы-ответы"
